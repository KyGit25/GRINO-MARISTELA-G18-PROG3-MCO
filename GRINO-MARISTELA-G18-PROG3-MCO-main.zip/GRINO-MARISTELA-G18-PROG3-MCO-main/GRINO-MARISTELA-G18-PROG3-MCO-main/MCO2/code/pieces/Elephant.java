public class Elephant extends Piece{

}